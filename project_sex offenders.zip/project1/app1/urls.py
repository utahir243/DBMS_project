from django.contrib import admin
from django.urls import path, include
from .views import HomePageView, PostDetailView, LogInView, SearchView, ResultView 
from . import views

app_name = 'app1'

urlpatterns = [
    path('',views.HomePageView, name='index'),
    path('detail/<int:pk>/', PostDetailView.as_view(), name='detail'),
    path('login',views.LogInView, name='login'),
    path('search',views.SearchView, name='search'),
    path('result',views.ResultView, name='result'),
    path('output', views.Offenders_list, name='Offenders_data'),
    path('signup', views.SignUpView, name='signup'),
    
]


# path('', HomePageView.as_view(), name='index'),
#     path('detail/<int:pk>/', PostDetailView.as_view(), name='detail'),
#     path('login',LogInView.as_view(), name='login'),
#     path('search',SearchView.as_view(), name='search'),
#     path('result',ResultView.as_view(), name='result'),
#     path('output', views.Offenders_list, name='Offenders_data'),