from django.contrib import admin
from .models import Post,Users,AccData,Admin,Casedetail,Offenders,Department

# Register your models here.
class PostAdmin(admin.ModelAdmin):
    pass


class UserAdmin(admin.ModelAdmin):
    pass


class AccAdmin(admin.ModelAdmin):
    pass


class AdminAdmin(admin.ModelAdmin):
    pass


class CasedetailAdmin(admin.ModelAdmin):
    pass


class OffendersAdmin(admin.ModelAdmin):
    pass


class DepartmentAdmin(admin.ModelAdmin):
    pass





admin.site.register(Post, PostAdmin)
admin.site.register(Users, UserAdmin)
admin.site.register(AccData, AccAdmin)
admin.site.register(Admin, AdminAdmin)
admin.site.register(Offenders, OffendersAdmin)
admin.site.register(Casedetail, CasedetailAdmin)
admin.site.register(Department, DepartmentAdmin)
