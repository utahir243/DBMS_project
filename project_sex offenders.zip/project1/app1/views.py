from tarfile import BLOCKSIZE
from django.views.generic import TemplateView, DetailView ,FormView
from .models import Offenders, Post
from django.http import HttpResponseRedirect
from django.shortcuts import redirect, render
from .models import Offenders,AccData
from django.db import connection
from django.db.models import Q
from . import models



#class HomePageView(TemplateView):
#    template_name = "home.html"


class PostDetailView(DetailView):
    template_name = "detail.html"
    model = Post

#class LogInView(TemplateView):
#    template_name = "login.html"


#class SearchView(TemplateView):
#    template_name = "search.html"

#class ResultView(TemplateView):
#    template_name = "result.html"

def ResultView(request):

    posts = Offenders.objects.all()
    return render(request, 'result.html',{'posts':posts})


def SearchView(request):
    
    #     print('post request')   
    # user = request.POST.get('username')
    # password = request.POST.get('password')
    # print(user)
    # # pass_word = request.user.get
    # posts = AccData.objects.filter(email__startswith=user)
    # if user == AccData.objects.filter(email__startswith=user):
    #     print(user)
    #     if password == AccData.objects.password.filter(email__startswith=user):
    #         print(password)
    #         # return render(request,'search.html')
    #     print("executed")        

    # print(f"user is: {request.POST.get('log',False)}" )
    return render(request, 'search.html',{'posts':"posts"})


def HomePageView(request):

    return render(request, 'home.html')


def LogInView(request):
    
    
    
    return render(request, 'login.html')

def SignUpView(request):
    posts = Offenders.objects.all()
    if request.method == 'POST':
        if request.POST.get('username') and request.POST.get('SSN') and request.POST.get('email') and request.POST.get('password'):
            post = AccData()
            
            post.email = request.POST.get('email')
            post.password = request.POST.get('password')
            post.status = 'UA'
            post.save()

            return render(request, 'login.html')
    else:    
        return render(request, 'signup.html')


def Offenders_list_(request):
    if request == 'POST':
        print('post request')   

    print(f"user is: {request.POST['log']}" )
    
    posts = Offenders.objects.all()

    print(posts)
    print(posts.query)
    print(connection.queries)

    return render(request, 'output.html',{'posts':posts})



def Offenders_list(request):
    search = request.POST.get('search')
    posts = Offenders.objects.filter(Q (first_name__startswith=search))

    print(posts)
    print(connection.queries)

    return render(request, 'output.html',{'posts':posts})     


def get_name():
    pass



